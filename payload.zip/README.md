# NetworkHooks iOS arm64

This project builds a new dylib containing only the four symbol rebindings observed in the comparison binary: `getaddrinfo`, `recvmsg`, `send`, and `recv`. It does not include any other code or offsets from that binary.

`payload.zip` contains `network_hooks.c`. The GitHub workflow unzips it, downloads a pinned revision of [fishhook](https://github.com/facebook/fishhook), compiles an arm64 iOS dylib, signs the dylib ad hoc, and uploads `NetworkHooks-ios-arm64.zip`.

## GitHub build

1. Create a GitHub repository and upload **all files and folders** from this directory, including `.github/workflows/build.yml` and `payload.zip`.
2. Open **Actions → Build iOS network hooks → Run workflow**.
3. `real_open_default` defaults to `0`, matching the comparison dylib's delayed activation: both flags stay off until an external caller invokes `network_hooks_set_url_open(1)`. Select `1` only to enable both during library initialization.
4. Download the `NetworkHooks-ios-arm64` artifact. Unzip it, then unzip the contained `NetworkHooks-ios-arm64.zip` to get the dylib.

The exported `network_hooks_set_url_open(int)` mirrors the observed `setUrlopen:` method: it sets both flags to the same value. When enabled, a timer toggles `realOpen` after 10 seconds, toggles it back after another 5 seconds, then schedules the next toggle after 999,999,999 seconds. The `network_hooks_set_real_open(int)` and getter functions allow direct control. In the comparison binary, `setUrlopen:` is reached through its own status and UI branches. Those branches are unavailable in a standalone dylib, so this source requires an explicit call from a verified integration point. It does not detect match entry.

The DNS hook redirects any `getaddrinfo` node/service string containing `sharkios` to `168.198.161.199:80`, matching the observed branch. When the flag is on, the three I/O hooks return `1` without calling the original functions. This behavior can disrupt connections or data handling. A successful build verifies the Mach-O file and exported control functions, but does not verify that an injected IPA loads it or that gameplay remains stable. The IPA must be modified to load the dylib and signed as a complete app package after modification.
