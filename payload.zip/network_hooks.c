#include <dlfcn.h>
#include <dispatch/dispatch.h>
#include <netdb.h>
#include <objc/message.h>
#include <objc/runtime.h>
#include <stdatomic.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>

#include "fishhook.h"

typedef int (*getaddrinfo_fn)(const char *, const char *,
                              const struct addrinfo *, struct addrinfo **);
typedef ssize_t (*recvmsg_fn)(int, struct msghdr *, int);
typedef ssize_t (*send_fn)(int, const void *, size_t, int);
typedef ssize_t (*recv_fn)(int, void *, size_t, int);

static getaddrinfo_fn original_getaddrinfo;
static recvmsg_fn original_recvmsg;
static send_fn original_send;
static recv_fn original_recv;
static _Atomic int real_open = 0;
static _Atomic int url_open = 0;
static _Atomic uint64_t timer_generation = 0;
static _Atomic int hud_online = 0;

struct timer_context {
    uint64_t generation;
};

static void schedule_toggle(uint64_t generation, int64_t seconds);
static void poll_hud_online(void *unused);
void network_hooks_set_url_open(int enabled);

static int read_hud_online(void) {
    Class hud_class = (Class)objc_getClass("LVDHUD");
    if (hud_class == Nil) {
        return 0;
    }

    SEL shared_selector = sel_registerName("shared");
    SEL online_selector = sel_registerName("lastOnline");
    if (class_getClassMethod(hud_class, shared_selector) == NULL ||
        class_getInstanceMethod(hud_class, online_selector) == NULL) {
        return 0;
    }

    id (*get_shared)(id, SEL) = (id (*)(id, SEL))objc_msgSend;
    BOOL (*get_online)(id, SEL) = (BOOL (*)(id, SEL))objc_msgSend;
    id hud = get_shared((id)hud_class, shared_selector);
    return hud != nil && get_online(hud, online_selector) ? 1 : 0;
}

static void poll_hud_online(void *unused) {
    (void)unused;
    int online = read_hud_online();
    int previous = atomic_exchange_explicit(&hud_online, online,
                                            memory_order_acq_rel);
    if (online != previous) {
        network_hooks_set_url_open(online);
    }
    dispatch_after_f(dispatch_time(DISPATCH_TIME_NOW, 250000000LL),
                     dispatch_get_main_queue(), NULL, poll_hud_online);
}

static void toggle_after_delay(void *opaque) {
    struct timer_context *context = (struct timer_context *)opaque;
    uint64_t expected = context->generation;
    free(context);

    if (atomic_load_explicit(&timer_generation, memory_order_acquire) != expected ||
        !atomic_load_explicit(&url_open, memory_order_acquire)) {
        return;
    }

    int next = !atomic_load_explicit(&real_open, memory_order_acquire);
    atomic_store_explicit(&real_open, next, memory_order_release);
    schedule_toggle(expected, next ? 999999999LL : 5LL);
}

static void schedule_toggle(uint64_t generation, int64_t seconds) {
    struct timer_context *context = malloc(sizeof(*context));
    if (context == NULL) {
        return;
    }
    context->generation = generation;
    dispatch_after_f(dispatch_time(DISPATCH_TIME_NOW, seconds * NSEC_PER_SEC),
                     dispatch_get_main_queue(), context, toggle_after_delay);
}

__attribute__((visibility("default")))
void network_hooks_set_url_open(int enabled) {
    int value = enabled != 0;
    uint64_t generation = atomic_fetch_add_explicit(
        &timer_generation, 1, memory_order_acq_rel) + 1;
    atomic_store_explicit(&url_open, value, memory_order_release);
    atomic_store_explicit(&real_open, value, memory_order_release);
    if (value) {
        schedule_toggle(generation, 10LL);
    }
}

__attribute__((visibility("default")))
int network_hooks_get_url_open(void) {
    return atomic_load_explicit(&url_open, memory_order_acquire);
}

__attribute__((visibility("default")))
int network_hooks_get_hud_online(void) {
    return atomic_load_explicit(&hud_online, memory_order_acquire);
}

__attribute__((visibility("default")))
void network_hooks_set_real_open(int enabled) {
    atomic_store_explicit(&real_open, enabled != 0, memory_order_release);
}

__attribute__((visibility("default")))
int network_hooks_get_real_open(void) {
    return atomic_load_explicit(&real_open, memory_order_acquire);
}

static int hooked_getaddrinfo(const char *node, const char *service,
                              const struct addrinfo *hints,
                              struct addrinfo **result) {
    if (original_getaddrinfo == NULL) {
        return EAI_SYSTEM;
    }
    if (!atomic_load_explicit(&hud_online, memory_order_acquire)) {
        return original_getaddrinfo(node, service, hints, result);
    }

    char target[4096];
    int written = snprintf(target, sizeof(target), "%s:%s",
                           node != NULL ? node : "(null)",
                           service != NULL ? service : "(null)");
    if (written >= 0 && (size_t)written < sizeof(target) &&
        strstr(target, "sharkios") != NULL) {
        return original_getaddrinfo("168.198.161.199", "80", hints, result);
    }
    return original_getaddrinfo(node, service, hints, result);
}

static ssize_t hooked_recvmsg(int fd, struct msghdr *message, int flags) {
    if (atomic_load_explicit(&hud_online, memory_order_acquire) &&
        network_hooks_get_real_open()) {
        return 1;
    }
    return original_recvmsg != NULL ? original_recvmsg(fd, message, flags) : -1;
}

static ssize_t hooked_send(int fd, const void *buffer, size_t length, int flags) {
    if (atomic_load_explicit(&hud_online, memory_order_acquire) &&
        network_hooks_get_real_open()) {
        return 1;
    }
    return original_send != NULL ? original_send(fd, buffer, length, flags) : -1;
}

static ssize_t hooked_recv(int fd, void *buffer, size_t length, int flags) {
    if (atomic_load_explicit(&hud_online, memory_order_acquire) &&
        network_hooks_get_real_open()) {
        return 1;
    }
    return original_recv != NULL ? original_recv(fd, buffer, length, flags) : -1;
}

__attribute__((constructor))
static void install_network_hooks(void) {
    original_getaddrinfo = (getaddrinfo_fn)dlsym(RTLD_NEXT, "getaddrinfo");
    original_recvmsg = (recvmsg_fn)dlsym(RTLD_NEXT, "recvmsg");
    original_send = (send_fn)dlsym(RTLD_NEXT, "send");
    original_recv = (recv_fn)dlsym(RTLD_NEXT, "recv");

    if (original_getaddrinfo == NULL || original_recvmsg == NULL ||
        original_send == NULL || original_recv == NULL) {
        return;
    }

    struct rebinding hooks[] = {
        {"getaddrinfo", (void *)hooked_getaddrinfo, NULL},
        {"recvmsg", (void *)hooked_recvmsg, NULL},
        {"send", (void *)hooked_send, NULL},
        {"recv", (void *)hooked_recv, NULL},
    };
    if (rebind_symbols(hooks, sizeof(hooks) / sizeof(hooks[0])) != 0) {
        return;
    }
    dispatch_async_f(dispatch_get_main_queue(), NULL, poll_hud_online);
}
