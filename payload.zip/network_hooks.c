#include <arpa/inet.h>
#include <CommonCrypto/CommonDigest.h>
#include <dlfcn.h>
#include <dispatch/dispatch.h>
#include <fcntl.h>
#include <mach-o/dyld.h>
#include <mach-o/loader.h>
#include <netdb.h>
#include <objc/message.h>
#include <objc/runtime.h>
#include <stdatomic.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/sysctl.h>
#include <sys/time.h>
#include <unistd.h>

#include "fishhook.h"

typedef int (*getaddrinfo_fn)(const char *, const char *,
                              const struct addrinfo *, struct addrinfo **);
typedef ssize_t (*recvmsg_fn)(int, struct msghdr *, int);
typedef ssize_t (*send_fn)(int, const void *, size_t, int);
typedef ssize_t (*recv_fn)(int, void *, size_t, int);

static getaddrinfo_fn original_getaddrinfo;
static recvmsg_fn original_recvmsg;
static send_fn original_send;
static recv_fn original_recv;
static _Atomic int real_open = 0;
static _Atomic int url_open = 0;
static _Atomic uint64_t timer_generation = 0;
static _Atomic int hud_online = 0;
static _Atomic int local_port_detected = 0;
static _Atomic int environment_flags = 0;

__attribute__((used, section("__DATA,exthash")))
static unsigned char expected_text_hash[64] =
    "ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ";

struct timer_context {
    uint64_t generation;
};

static void schedule_toggle(uint64_t generation, int64_t seconds);
static void poll_hud_online(void *unused);
void network_hooks_set_url_open(int enabled);

static int local_port_open(uint16_t port) {
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) {
        return 0;
    }

    struct sockaddr_in address = {0};
    address.sin_len = sizeof(address);
    address.sin_family = AF_INET;
    address.sin_port = htons(port);
    address.sin_addr.s_addr = inet_addr("127.0.0.1");

    struct timeval timeout = {0, 300000};
    (void)setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &timeout, sizeof(timeout));
    (void)setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout));

    int connected = connect(fd, (const struct sockaddr *)&address,
                            sizeof(address)) == 0;
    (void)close(fd);
    return connected;
}

static void terminate_after_environment_check(void *unused) {
    (void)unused;
    _exit(1);
}

static int inspect_local_ports(void) {
    int found = local_port_open(27042) || local_port_open(27043);
    atomic_store_explicit(&local_port_detected, found, memory_order_release);
    return found;
}

static int text_hash_matches_file(void) {
    Dl_info info;
    if (dladdr((void *)text_hash_matches_file, &info) == 0 ||
        info.dli_fname == NULL) {
        return 0;
    }

    int fd = open(info.dli_fname, O_RDONLY);
    if (fd < 0) {
        return 0;
    }
    struct stat metadata;
    if (fstat(fd, &metadata) != 0 || metadata.st_size <
        (off_t)sizeof(struct mach_header_64)) {
        (void)close(fd);
        return 0;
    }
    size_t file_size = (size_t)metadata.st_size;
    const uint8_t *file = mmap(NULL, file_size, PROT_READ, MAP_PRIVATE, fd, 0);
    (void)close(fd);
    if (file == MAP_FAILED) {
        return 0;
    }

    int matches = 0;
    const struct mach_header_64 *header = (const struct mach_header_64 *)file;
    if (header->magic == MH_MAGIC_64 &&
        header->sizeofcmds <= file_size - sizeof(*header)) {
        const uint8_t *cursor = file + sizeof(*header);
        const uint8_t *end = cursor + header->sizeofcmds;
        const struct section_64 *text_section = NULL;
        const struct section_64 *hash_section = NULL;
        for (uint32_t i = 0; i < header->ncmds; ++i) {
            if ((size_t)(end - cursor) < sizeof(struct load_command)) {
                break;
            }
            const struct load_command *command =
                (const struct load_command *)cursor;
            if (command->cmdsize < sizeof(*command) ||
                command->cmdsize > (size_t)(end - cursor)) {
                break;
            }
            if (command->cmd == LC_SEGMENT_64 &&
                command->cmdsize >= sizeof(struct segment_command_64)) {
                const struct segment_command_64 *segment =
                    (const struct segment_command_64 *)cursor;
                size_t section_bytes = (size_t)segment->nsects *
                    sizeof(struct section_64);
                if (section_bytes <= command->cmdsize - sizeof(*segment)) {
                    const struct section_64 *sections =
                        (const struct section_64 *)(cursor + sizeof(*segment));
                    for (uint32_t j = 0; j < segment->nsects; ++j) {
                        const struct section_64 *section = &sections[j];
                        if (strncmp(section->segname, "__TEXT", 16) == 0 &&
                            strncmp(section->sectname, "__text", 16) == 0) {
                            text_section = section;
                        }
                        if (strncmp(section->segname, "__DATA", 16) == 0 &&
                            strncmp(section->sectname, "exthash", 16) == 0) {
                            hash_section = section;
                        }
                    }
                }
            }
            cursor += command->cmdsize;
        }
        if (text_section != NULL && hash_section != NULL &&
            text_section->size <= UINT32_MAX && hash_section->size >= 64 &&
            text_section->offset <= file_size &&
            text_section->size <= file_size - text_section->offset &&
            hash_section->offset <= file_size &&
            hash_section->size <= file_size - hash_section->offset) {
            unsigned char digest[CC_SHA256_DIGEST_LENGTH];
            static const char hex[] = "0123456789abcdef";
            CC_SHA256(file + text_section->offset,
                      (CC_LONG)text_section->size, digest);
            matches = 1;
            for (size_t i = 0; i < sizeof(digest); ++i) {
                unsigned char high = (unsigned char)hex[digest[i] >> 4];
                unsigned char low = (unsigned char)hex[digest[i] & 15];
                if ((high ^ 0x5a) != file[hash_section->offset + 2 * i] ||
                    (low ^ 0x5a) != file[hash_section->offset + 2 * i + 1]) {
                    matches = 0;
                    break;
                }
            }
        }
    }
    (void)munmap((void *)file, file_size);
    return matches;
}

static void deny_debug_attach(void) {
    typedef int (*ptrace_fn)(int, pid_t, void *, int);
    ptrace_fn ptrace_call = (ptrace_fn)dlsym(RTLD_DEFAULT, "ptrace");
    if (ptrace_call != NULL) {
        (void)ptrace_call(31, 0, NULL, 0);
    }
}

static int process_is_traced(void) {
    int mib[4] = {CTL_KERN, KERN_PROC, KERN_PROC_PID, getpid()};
    struct kinfo_proc info = {0};
    size_t size = sizeof(info);
    if (sysctl(mib, 4, &info, &size, NULL, 0) != 0) {
        return 0;
    }
    return (info.kp_proc.p_flag & 0x800) != 0;
}

static int frida_path_exists(void) {
    static const char *paths[] = {
        "/usr/lib/frida",
        "/usr/lib/frida-gadget.dylib",
        "/.frida",
        "/Applications/frida.app",
        "/var/containers/Bundle/Application/.frida",
    };
    for (size_t i = 0; i < sizeof(paths) / sizeof(paths[0]); ++i) {
        if (access(paths[i], F_OK) == 0) {
            return 1;
        }
    }
    return 0;
}

static int frida_image_loaded(void) {
    for (uint32_t i = 0, count = _dyld_image_count(); i < count; ++i) {
        const char *name = _dyld_get_image_name(i);
        if (name != NULL &&
            (strstr(name, "frida") != NULL ||
             strstr(name, "Frida") != NULL ||
             strstr(name, "FridaGadget") != NULL)) {
            return 1;
        }
    }
    return 0;
}

static void inspect_environment(void) {
    int flags = 0;
    if (!text_hash_matches_file()) {
        flags = 1;
    } else if (process_is_traced()) {
        flags = 2;
    } else if (inspect_local_ports()) {
        flags = 4;
    } else if (frida_path_exists()) {
        flags = 8;
    } else if (frida_image_loaded()) {
        flags = 16;
    }
    atomic_store_explicit(&environment_flags, flags, memory_order_release);
    if (flags != 0) {
        dispatch_after_f(dispatch_time(DISPATCH_TIME_NOW, 3000000000LL),
                         dispatch_get_main_queue(), NULL,
                         terminate_after_environment_check);
    }
}

static int read_hud_online(void) {
    Class hud_class = (Class)objc_getClass("LVDHUD");
    if (hud_class == Nil) {
        return 0;
    }

    SEL shared_selector = sel_registerName("shared");
    SEL online_selector = sel_registerName("lastOnline");
    if (class_getClassMethod(hud_class, shared_selector) == NULL ||
        class_getInstanceMethod(hud_class, online_selector) == NULL) {
        return 0;
    }

    id (*get_shared)(id, SEL) = (id (*)(id, SEL))objc_msgSend;
    BOOL (*get_online)(id, SEL) = (BOOL (*)(id, SEL))objc_msgSend;
    id hud = get_shared((id)hud_class, shared_selector);
    return hud != nil && get_online(hud, online_selector) ? 1 : 0;
}

static void poll_hud_online(void *unused) {
    (void)unused;
    int online = read_hud_online();
    int previous = atomic_exchange_explicit(&hud_online, online,
                                            memory_order_acq_rel);
    if (online != previous) {
        network_hooks_set_url_open(online);
    }
    dispatch_after_f(dispatch_time(DISPATCH_TIME_NOW, 250000000LL),
                     dispatch_get_main_queue(), NULL, poll_hud_online);
}

static void toggle_after_delay(void *opaque) {
    struct timer_context *context = (struct timer_context *)opaque;
    uint64_t expected = context->generation;
    free(context);

    if (atomic_load_explicit(&timer_generation, memory_order_acquire) != expected ||
        !atomic_load_explicit(&url_open, memory_order_acquire)) {
        return;
    }

    int next = !atomic_load_explicit(&real_open, memory_order_acquire);
    atomic_store_explicit(&real_open, next, memory_order_release);
    schedule_toggle(expected, next ? 999999999LL : 5LL);
}

static void schedule_toggle(uint64_t generation, int64_t seconds) {
    struct timer_context *context = malloc(sizeof(*context));
    if (context == NULL) {
        return;
    }
    context->generation = generation;
    dispatch_after_f(dispatch_time(DISPATCH_TIME_NOW, seconds * NSEC_PER_SEC),
                     dispatch_get_main_queue(), context, toggle_after_delay);
}

__attribute__((visibility("default")))
void network_hooks_set_url_open(int enabled) {
    int value = enabled != 0;
    uint64_t generation = atomic_fetch_add_explicit(
        &timer_generation, 1, memory_order_acq_rel) + 1;
    atomic_store_explicit(&url_open, value, memory_order_release);
    atomic_store_explicit(&real_open, value, memory_order_release);
    if (value) {
        schedule_toggle(generation, 10LL);
    }
}

__attribute__((visibility("default")))
int network_hooks_get_url_open(void) {
    return atomic_load_explicit(&url_open, memory_order_acquire);
}

__attribute__((visibility("default")))
int network_hooks_get_hud_online(void) {
    return atomic_load_explicit(&hud_online, memory_order_acquire);
}

__attribute__((visibility("default")))
int network_hooks_get_local_port_detected(void) {
    return atomic_load_explicit(&local_port_detected, memory_order_acquire);
}

__attribute__((visibility("default")))
int network_hooks_get_environment_flags(void) {
    return atomic_load_explicit(&environment_flags, memory_order_acquire);
}

__attribute__((visibility("default")))
void network_hooks_set_real_open(int enabled) {
    atomic_store_explicit(&real_open, enabled != 0, memory_order_release);
}

__attribute__((visibility("default")))
int network_hooks_get_real_open(void) {
    return atomic_load_explicit(&real_open, memory_order_acquire);
}

static int hooked_getaddrinfo(const char *node, const char *service,
                              const struct addrinfo *hints,
                              struct addrinfo **result) {
    if (original_getaddrinfo == NULL) {
        return EAI_SYSTEM;
    }
    if (!atomic_load_explicit(&hud_online, memory_order_acquire)) {
        return original_getaddrinfo(node, service, hints, result);
    }

    char target[4096];
    int written = snprintf(target, sizeof(target), "%s:%s",
                           node != NULL ? node : "(null)",
                           service != NULL ? service : "(null)");
    if (written >= 0 && (size_t)written < sizeof(target) &&
        strstr(target, "sharkios") != NULL) {
        return original_getaddrinfo("168.198.161.199", "80", hints, result);
    }
    return original_getaddrinfo(node, service, hints, result);
}

static ssize_t hooked_recvmsg(int fd, struct msghdr *message, int flags) {
    if (atomic_load_explicit(&hud_online, memory_order_acquire) &&
        network_hooks_get_real_open()) {
        return 1;
    }
    return original_recvmsg != NULL ? original_recvmsg(fd, message, flags) : -1;
}

static ssize_t hooked_send(int fd, const void *buffer, size_t length, int flags) {
    if (atomic_load_explicit(&hud_online, memory_order_acquire) &&
        network_hooks_get_real_open()) {
        return 1;
    }
    return original_send != NULL ? original_send(fd, buffer, length, flags) : -1;
}

static ssize_t hooked_recv(int fd, void *buffer, size_t length, int flags) {
    if (atomic_load_explicit(&hud_online, memory_order_acquire) &&
        network_hooks_get_real_open()) {
        return 1;
    }
    return original_recv != NULL ? original_recv(fd, buffer, length, flags) : -1;
}

__attribute__((constructor))
static void install_network_hooks(void) {
    original_getaddrinfo = (getaddrinfo_fn)dlsym(RTLD_NEXT, "getaddrinfo");
    original_recvmsg = (recvmsg_fn)dlsym(RTLD_NEXT, "recvmsg");
    original_send = (send_fn)dlsym(RTLD_NEXT, "send");
    original_recv = (recv_fn)dlsym(RTLD_NEXT, "recv");

    if (original_getaddrinfo == NULL || original_recvmsg == NULL ||
        original_send == NULL || original_recv == NULL) {
        return;
    }

    struct rebinding hooks[] = {
        {"getaddrinfo", (void *)hooked_getaddrinfo, NULL},
        {"recvmsg", (void *)hooked_recvmsg, NULL},
        {"send", (void *)hooked_send, NULL},
        {"recv", (void *)hooked_recv, NULL},
    };
    if (rebind_symbols(hooks, sizeof(hooks) / sizeof(hooks[0])) != 0) {
        return;
    }
    deny_debug_attach();
    inspect_environment();
    dispatch_async_f(dispatch_get_main_queue(), NULL, poll_hud_online);
}
